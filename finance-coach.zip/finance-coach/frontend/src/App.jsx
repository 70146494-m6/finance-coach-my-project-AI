import { useState } from 'react'
import Dashboard from './components/Dashboard'
import Chatbot from './components/Chatbot'

export default function App() {
  const [refreshKey, setRefreshKey] = useState(0)

  const handleExpenseChange = () => setRefreshKey((k) => k + 1)

  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-lg font-bold shadow-lg shadow-brand-500/20">
              ₿
            </div>
            <div>
              <h1 className="text-lg font-semibold tracking-tight">Finance Coach</h1>
              <p className="text-xs text-slate-400">AI-powered personal finance</p>
            </div>
          </div>
          <span className="hidden sm:inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/10 text-brand-400 text-xs font-medium border border-brand-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-brand-400 animate-pulse" />
            Live demo
          </span>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          <div className="xl:col-span-2">
            <Dashboard refreshKey={refreshKey} onExpenseChange={handleExpenseChange} />
          </div>
          <div className="xl:col-span-1">
            <Chatbot />
          </div>
        </div>
      </main>
    </div>
  )
}
