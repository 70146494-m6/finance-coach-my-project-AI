import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'

export default function PredictionChart({ predictions, trend }) {
  if (!predictions?.length) return null

  const trendColors = {
    increasing: 'text-amber-400',
    decreasing: 'text-brand-400',
    stable: 'text-sky-400',
  }

  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-slate-200">Spending forecast</h3>
        <span
          className={`text-xs font-medium capitalize px-2 py-0.5 rounded-full bg-slate-800 ${
            trendColors[trend] || trendColors.stable
          }`}
        >
          {trend}
        </span>
      </div>
      <div className="h-48">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={predictions} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
            <XAxis
              dataKey="month"
              tick={{ fill: '#94a3b8', fontSize: 11 }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              tick={{ fill: '#94a3b8', fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              tickFormatter={(v) => `$${v}`}
            />
            <Tooltip
              contentStyle={{
                background: '#1e293b',
                border: '1px solid #334155',
                borderRadius: '8px',
                fontSize: '12px',
              }}
              formatter={(value, name, props) => [
                `$${Number(value).toLocaleString()}`,
                `Predicted (${Math.round(props.payload.confidence * 100)}% conf.)`,
              ]}
            />
            <Bar
              dataKey="predicted_amount"
              fill="#10b981"
              radius={[6, 6, 0, 0]}
              name="Predicted"
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
