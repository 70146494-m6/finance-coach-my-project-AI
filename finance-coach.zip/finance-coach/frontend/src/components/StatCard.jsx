export default function StatCard({ label, value, sub, accent = 'brand' }) {
  const accents = {
    brand: 'from-brand-500/20 to-transparent border-brand-500/30',
    amber: 'from-amber-500/20 to-transparent border-amber-500/30',
    violet: 'from-violet-500/20 to-transparent border-violet-500/30',
  }

  return (
    <div
      className={`rounded-2xl border bg-gradient-to-br p-5 ${accents[accent] || accents.brand}`}
    >
      <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">{label}</p>
      <p className="mt-2 text-2xl font-bold text-white tabular-nums">{value}</p>
      {sub && <p className="mt-1 text-sm text-slate-400">{sub}</p>}
    </div>
  )
}
