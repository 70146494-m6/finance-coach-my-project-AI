import { useEffect, useState } from 'react'
import { api } from '../api'

const CATEGORY_COLORS = {
  housing: 'bg-rose-500',
  food: 'bg-amber-500',
  transport: 'bg-sky-500',
  entertainment: 'bg-violet-500',
  health: 'bg-emerald-500',
  shopping: 'bg-pink-500',
  utilities: 'bg-cyan-500',
  other: 'bg-slate-500',
}

export default function AddExpenseForm({ onAdded }) {
  const [categories, setCategories] = useState([])
  const [amount, setAmount] = useState('')
  const [category, setCategory] = useState('food')
  const [description, setDescription] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    api.getCategories().then(setCategories).catch(console.error)
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      await api.addExpense({
        amount: parseFloat(amount),
        category,
        description,
      })
      setAmount('')
      setDescription('')
      onAdded?.()
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5">
      <h3 className="text-sm font-semibold text-slate-200 mb-4">Add expense</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs text-slate-400 mb-1">Amount ($)</label>
          <input
            type="number"
            step="0.01"
            min="0.01"
            required
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/50"
            placeholder="0.00"
          />
        </div>
        <div>
          <label className="block text-xs text-slate-400 mb-1">Category</label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/50"
          >
            {categories.map((c) => (
              <option key={c.value} value={c.value}>
                {c.label}
              </option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className="block text-xs text-slate-400 mb-1">Description</label>
          <input
            type="text"
            required
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/50"
            placeholder="What was this for?"
          />
        </div>
      </div>
      {error && <p className="mt-2 text-xs text-rose-400">{error}</p>}
      <button
        type="submit"
        disabled={loading}
        className="mt-4 w-full rounded-lg bg-brand-600 hover:bg-brand-500 disabled:opacity-50 text-white text-sm font-medium py-2.5 transition-colors"
      >
        {loading ? 'Adding…' : 'Add expense'}
      </button>
      <div className="mt-3 flex flex-wrap gap-1.5">
        {Object.entries(CATEGORY_COLORS).slice(0, 6).map(([cat, color]) => (
          <span key={cat} className="inline-flex items-center gap-1 text-[10px] text-slate-500">
            <span className={`w-2 h-2 rounded-full ${color}`} />
            {cat}
          </span>
        ))}
      </div>
    </form>
  )
}
