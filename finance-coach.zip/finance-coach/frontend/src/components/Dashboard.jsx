import { useCallback, useEffect, useState } from 'react'
import { api } from '../api'
import AddExpenseForm from './AddExpenseForm'
import CategoryChart from './CategoryChart'
import ExpenseList from './ExpenseList'
import PredictionChart from './PredictionChart'
import StatCard from './StatCard'

export default function Dashboard({ refreshKey, onExpenseChange }) {
  const [summary, setSummary] = useState(null)
  const [expenses, setExpenses] = useState([])
  const [predictions, setPredictions] = useState(null)
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [s, e, p] = await Promise.all([
        api.getSummary(30),
        api.getExpenses(30),
        api.getPredictions(3),
      ])
      setSummary(s)
      setExpenses(e)
      setPredictions(p)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load, refreshKey])

  const handleDelete = async (id) => {
    await api.deleteExpense(id)
    onExpenseChange?.()
  }

  const handleAdded = () => onExpenseChange?.()

  if (loading && !summary) {
    return (
      <div className="flex items-center justify-center h-64 text-slate-500 text-sm">
        Loading dashboard…
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard
          label="Total (30 days)"
          value={`$${summary?.total_spent?.toLocaleString() ?? '0'}`}
          sub={`${summary?.expense_count ?? 0} transactions`}
        />
        <StatCard
          label="Monthly average"
          value={`$${summary?.monthly_average?.toLocaleString() ?? '0'}`}
          accent="amber"
        />
        <StatCard
          label="Forecast trend"
          value={predictions?.trend ?? '—'}
          sub={predictions?.insight?.slice(0, 60) + (predictions?.insight?.length > 60 ? '…' : '')}
          accent="violet"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <CategoryChart byCategory={summary?.by_category} />
        <PredictionChart
          predictions={predictions?.predictions}
          trend={predictions?.trend}
        />
      </div>

      {predictions?.insight && (
        <div className="rounded-xl border border-brand-500/20 bg-brand-500/5 px-4 py-3 text-sm text-brand-200">
          {predictions.insight}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5">
          <h3 className="text-sm font-semibold text-slate-200 mb-3">Recent expenses</h3>
          <ExpenseList expenses={expenses} onDelete={handleDelete} />
        </div>
        <AddExpenseForm onAdded={handleAdded} />
      </div>
    </div>
  )
}
