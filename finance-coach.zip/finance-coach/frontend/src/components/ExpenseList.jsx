const CATEGORY_COLORS = {
  housing: 'text-rose-400 bg-rose-500/10',
  food: 'text-amber-400 bg-amber-500/10',
  transport: 'text-sky-400 bg-sky-500/10',
  entertainment: 'text-violet-400 bg-violet-500/10',
  health: 'text-emerald-400 bg-emerald-500/10',
  shopping: 'text-pink-400 bg-pink-500/10',
  utilities: 'text-cyan-400 bg-cyan-500/10',
  other: 'text-slate-400 bg-slate-500/10',
}

function formatDate(d) {
  return new Date(d + 'T12:00:00').toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
  })
}

export default function ExpenseList({ expenses, onDelete }) {
  if (!expenses?.length) {
    return (
      <p className="text-sm text-slate-500 py-8 text-center">No expenses yet.</p>
    )
  }

  return (
    <ul className="divide-y divide-slate-800 max-h-80 overflow-y-auto scrollbar-thin">
      {expenses.map((e) => (
        <li key={e.id} className="flex items-center justify-between py-3 px-1 group">
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium text-slate-200 truncate">{e.description}</p>
            <div className="flex items-center gap-2 mt-0.5">
              <span
                className={`text-[10px] font-medium px-1.5 py-0.5 rounded capitalize ${
                  CATEGORY_COLORS[e.category] || CATEGORY_COLORS.other
                }`}
              >
                {e.category}
              </span>
              <span className="text-xs text-slate-500">{formatDate(e.date)}</span>
            </div>
          </div>
          <div className="flex items-center gap-2 ml-3">
            <span className="text-sm font-semibold tabular-nums text-white">
              ${e.amount.toFixed(2)}
            </span>
            <button
              type="button"
              onClick={() => onDelete(e.id)}
              className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-rose-400 text-xs transition-opacity"
              title="Delete"
            >
              ✕
            </button>
          </div>
        </li>
      ))}
    </ul>
  )
}
