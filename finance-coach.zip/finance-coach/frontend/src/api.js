const API_BASE = '/api'

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || 'Request failed')
  }
  return res.json()
}

export const api = {
  getExpenses: (days) => request(`/expenses${days ? `?days=${days}` : ''}`),
  getSummary: (days = 30) => request(`/summary?days=${days}`),
  getPredictions: (months = 3) => request(`/predictions?months=${months}`),
  getCategories: () => request('/categories'),
  addExpense: (data) =>
    request('/expenses', { method: 'POST', body: JSON.stringify(data) }),
  deleteExpense: (id) => request(`/expenses/${id}`, { method: 'DELETE' }),
  chat: (message, history) =>
    request('/chat', {
      method: 'POST',
      body: JSON.stringify({ message, history }),
    }),
}
