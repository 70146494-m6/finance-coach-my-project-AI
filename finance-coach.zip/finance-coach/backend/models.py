from datetime import date
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class ExpenseCategory(str, Enum):
    HOUSING = "housing"
    FOOD = "food"
    TRANSPORT = "transport"
    ENTERTAINMENT = "entertainment"
    HEALTH = "health"
    SHOPPING = "shopping"
    UTILITIES = "utilities"
    OTHER = "other"


class ExpenseCreate(BaseModel):
    amount: float = Field(gt=0, description="Expense amount in USD")
    category: ExpenseCategory
    description: str = Field(min_length=1, max_length=200)
    date: Optional[date] = None


class Expense(BaseModel):
    id: int
    amount: float
    category: ExpenseCategory
    description: str
    date: date


class ExpenseSummary(BaseModel):
    total_spent: float
    monthly_average: float
    by_category: dict[str, float]
    expense_count: int


class PredictionPoint(BaseModel):
    month: str
    predicted_amount: float
    confidence: float


class PredictionResponse(BaseModel):
    predictions: list[PredictionPoint]
    trend: str
    insight: str


class ChatMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=2000)
    history: list[ChatMessage] = []


class ChatResponse(BaseModel):
    reply: str
    suggestions: list[str] = []
