from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from models import (
    ChatRequest,
    ChatResponse,
    Expense,
    ExpenseCategory,
    ExpenseCreate,
    ExpenseSummary,
    PredictionResponse,
)
from services.ai_chat_service import AIChatService
from services.expense_service import ExpenseService
from services.prediction_service import PredictionService

app = FastAPI(
    title="AI Personal Finance Coach",
    description="Expense tracking, predictions, and AI coaching API",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

expense_service = ExpenseService()
prediction_service = PredictionService(expense_service)
ai_chat_service = AIChatService(expense_service, prediction_service)


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "finance-coach-api"}


@app.get("/api/expenses", response_model=list[Expense])
def list_expenses(
    category: Optional[ExpenseCategory] = None,
    days: Optional[int] = None,
):
    return expense_service.list_expenses(category=category, days=days)


@app.post("/api/expenses", response_model=Expense, status_code=201)
def create_expense(data: ExpenseCreate):
    return expense_service.add_expense(data)


@app.delete("/api/expenses/{expense_id}")
def delete_expense(expense_id: int):
    if not expense_service.delete_expense(expense_id):
        raise HTTPException(status_code=404, detail="Expense not found")
    return {"ok": True}


@app.get("/api/summary", response_model=ExpenseSummary)
def get_summary(days: int = 30):
    return expense_service.get_summary(days=days)


@app.get("/api/predictions", response_model=PredictionResponse)
def get_predictions(months: int = 3):
    return prediction_service.predict(months_ahead=months)


@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    return await ai_chat_service.chat(request.message, request.history)


@app.get("/api/categories")
def list_categories():
    return [{"value": c.value, "label": c.value.replace("_", " ").title()} for c in ExpenseCategory]
