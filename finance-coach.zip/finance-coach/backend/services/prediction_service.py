from collections import defaultdict
from datetime import date
from statistics import mean

from models import PredictionPoint, PredictionResponse
from services.expense_service import ExpenseService


class PredictionService:
    """Simple linear trend + seasonal adjustment for future expense forecasts."""

    def __init__(self, expense_service: ExpenseService) -> None:
        self._expenses = expense_service

    def predict(self, months_ahead: int = 3) -> PredictionResponse:
        expenses = self._expenses.list_expenses(days=90)
        if not expenses:
            return PredictionResponse(
                predictions=[],
                trend="stable",
                insight="Add expenses to enable predictions.",
            )

        monthly_totals: dict[str, float] = defaultdict(float)
        for e in expenses:
            key = e.date.strftime("%Y-%m")
            monthly_totals[key] += e.amount

        sorted_months = sorted(monthly_totals.keys())
        values = [monthly_totals[m] for m in sorted_months]

        if len(values) == 1:
            base = values[0]
            trend_slope = 0.0
        else:
            base = mean(values[-3:]) if len(values) >= 3 else mean(values)
            trend_slope = (values[-1] - values[0]) / max(len(values) - 1, 1)

        trend = "increasing" if trend_slope > 50 else "decreasing" if trend_slope < -50 else "stable"

        predictions: list[PredictionPoint] = []
        today = date.today()
        for i in range(1, months_ahead + 1):
            month_offset = (today.month + i - 1) % 12 + 1
            year_offset = today.year + (today.month + i - 1) // 12
            label = date(year_offset, month_offset, 1).strftime("%b %Y")
            predicted = max(base + trend_slope * i, 0)
            confidence = max(0.55, 0.92 - i * 0.1)
            predictions.append(
                PredictionPoint(
                    month=label,
                    predicted_amount=round(predicted, 2),
                    confidence=round(confidence, 2),
                )
            )

        insight = self._build_insight(trend, base, trend_slope)
        return PredictionResponse(predictions=predictions, trend=trend, insight=insight)

    def _build_insight(self, trend: str, base: float, slope: float) -> str:
        if trend == "increasing":
            return (
                f"Spending is trending up (~${abs(slope):.0f}/month). "
                f"Consider reviewing discretionary categories to stay near ${base:.0f}/month."
            )
        if trend == "decreasing":
            return (
                f"Great progress — spending is trending down. "
                f"Your recent monthly average is around ${base:.0f}."
            )
        return (
            f"Spending looks stable around ${base:.0f}/month. "
            "Keep tracking to spot changes early."
        )
