import os
import re
from typing import Optional

import httpx

from models import ChatMessage, ChatResponse
from services.expense_service import ExpenseService
from services.prediction_service import PredictionService


class AIChatService:
    """Finance coach chat: OpenAI when configured, otherwise rule-based coach."""

    def __init__(
        self,
        expense_service: ExpenseService,
        prediction_service: PredictionService,
    ) -> None:
        self._expenses = expense_service
        self._predictions = prediction_service
        self._openai_key = os.getenv("OPENAI_API_KEY")

    async def chat(self, message: str, history: list[ChatMessage]) -> ChatResponse:
        if self._openai_key:
            try:
                reply = await self._openai_chat(message, history)
                return ChatResponse(reply=reply, suggestions=self._suggestions())
            except Exception:
                pass
        return self._rule_based_chat(message)

    async def _openai_chat(self, message: str, history: list[ChatMessage]) -> str:
        summary = self._expenses.get_summary()
        prediction = self._predictions.predict()
        context = (
            f"User finances (last 30 days): total ${summary.total_spent}, "
            f"monthly avg ${summary.monthly_average}, "
            f"by category {summary.by_category}. "
            f"Trend: {prediction.trend}. Insight: {prediction.insight}"
        )
        messages = [
            {
                "role": "system",
                "content": (
                    "You are a friendly, concise personal finance coach. "
                    "Give practical advice. Use the user's data when relevant. "
                    f"Context: {context}"
                ),
            },
        ]
        for h in history[-6:]:
            messages.append({"role": h.role, "content": h.content})
        messages.append({"role": "user", "content": message})

        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {self._openai_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
                    "messages": messages,
                    "max_tokens": 500,
                    "temperature": 0.7,
                },
            )
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"]

    def _rule_based_chat(self, message: str) -> ChatResponse:
        text = message.lower().strip()
        summary = self._expenses.get_summary()
        prediction = self._predictions.predict()

        if any(w in text for w in ["hello", "hi", "hey", "start"]):
            reply = (
                f"Hi! I'm your finance coach. Over the last 30 days you've spent "
                f"${summary.total_spent:,.2f} across {summary.expense_count} transactions. "
                "Ask me about budgets, categories, or future spending."
            )
        elif any(w in text for w in ["predict", "forecast", "future", "next month"]):
            lines = [f"**{p.month}**: ~${p.predicted_amount:,.2f} ({int(p.confidence * 100)}% confidence)" for p in prediction.predictions]
            reply = f"Here's your spending forecast:\n\n" + "\n".join(lines) + f"\n\n{prediction.insight}"
        elif any(w in text for w in ["budget", "save", "saving", "reduce"]):
            top = max(summary.by_category.items(), key=lambda x: x[1], default=("other", 0))
            reply = (
                f"Your largest category is **{top[0]}** at ${top[1]:,.2f}. "
                "Try the 50/30/20 rule: 50% needs, 30% wants, 20% savings. "
                f"With ~${summary.monthly_average:,.0f}/month spending, aim to save "
                f"${summary.monthly_average * 0.2:,.0f} monthly."
            )
        elif any(w in text for w in ["category", "categories", "breakdown", "spending"]):
            if summary.by_category:
                lines = [f"• **{k.title()}**: ${v:,.2f}" for k, v in sorted(summary.by_category.items(), key=lambda x: -x[1])]
                reply = "Spending by category (last 30 days):\n\n" + "\n".join(lines)
            else:
                reply = "No category data yet. Add some expenses first!"
        elif any(w in text for w in ["total", "spent", "how much"]):
            reply = (
                f"In the last 30 days: **${summary.total_spent:,.2f}** total, "
                f"**${summary.monthly_average:,.2f}** monthly average."
            )
        elif "tip" in text or "advice" in text:
            tips = [
                "Track every expense for 2 weeks — awareness alone cuts spending ~10%.",
                "Set up automatic transfers to savings on payday.",
                "Review subscriptions monthly; cancel what you haven't used in 30 days.",
                "Use the envelope method for discretionary categories.",
            ]
            import random
            reply = f"💡 **Tip:** {random.choice(tips)}"
        elif match := re.search(r"add\s+(\d+(?:\.\d+)?)\s+(\w+)", text):
            reply = (
                f"To log ${match.group(1)} for {match.group(2)}, use the "
                "**Add Expense** form on the dashboard."
            )
        else:
            reply = (
                "I can help with:\n"
                "• **Spending breakdown** — ask about categories\n"
                "• **Forecasts** — ask about predictions\n"
                "• **Budget tips** — ask how to save\n"
                "• **Totals** — ask how much you've spent\n\n"
                f"Quick stat: ${summary.monthly_average:,.0f}/month average. "
                "Set `OPENAI_API_KEY` for smarter AI replies."
            )

        return ChatResponse(reply=reply, suggestions=self._suggestions())

    def _suggestions(self) -> list[str]:
        return [
            "What's my spending breakdown?",
            "Predict my expenses next month",
            "How can I save more?",
            "Give me a money tip",
        ]
