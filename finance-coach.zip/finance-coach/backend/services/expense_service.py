from datetime import date, timedelta
from typing import Optional

from models import Expense, ExpenseCategory, ExpenseCreate, ExpenseSummary


class ExpenseService:
    """In-memory expense tracker with seeded sample data."""

    def __init__(self) -> None:
        self._expenses: list[Expense] = []
        self._next_id = 1
        self._seed_sample_data()

    def _seed_sample_data(self) -> None:
        today = date.today()
        samples = [
            (89.50, ExpenseCategory.FOOD, "Weekly groceries", today - timedelta(days=2)),
            (45.00, ExpenseCategory.TRANSPORT, "Gas fill-up", today - timedelta(days=3)),
            (1200.00, ExpenseCategory.HOUSING, "Rent payment", today - timedelta(days=5)),
            (35.99, ExpenseCategory.ENTERTAINMENT, "Streaming subscription", today - timedelta(days=7)),
            (78.20, ExpenseCategory.FOOD, "Restaurant dinner", today - timedelta(days=10)),
            (150.00, ExpenseCategory.HEALTH, "Gym membership", today - timedelta(days=12)),
            (62.40, ExpenseCategory.SHOPPING, "Clothing", today - timedelta(days=15)),
            (95.00, ExpenseCategory.UTILITIES, "Electric bill", today - timedelta(days=18)),
            (28.50, ExpenseCategory.FOOD, "Coffee & snacks", today - timedelta(days=20)),
            (200.00, ExpenseCategory.TRANSPORT, "Car maintenance", today - timedelta(days=25)),
            (55.00, ExpenseCategory.ENTERTAINMENT, "Movie tickets", today - timedelta(days=28)),
            (42.00, ExpenseCategory.FOOD, "Lunch delivery", today - timedelta(days=32)),
            (1100.00, ExpenseCategory.HOUSING, "Previous rent", today - timedelta(days=35)),
            (88.00, ExpenseCategory.UTILITIES, "Internet", today - timedelta(days=40)),
            (67.30, ExpenseCategory.SHOPPING, "Home supplies", today - timedelta(days=45)),
        ]
        for amount, category, description, expense_date in samples:
            self._expenses.append(
                Expense(
                    id=self._next_id,
                    amount=amount,
                    category=category,
                    description=description,
                    date=expense_date,
                )
            )
            self._next_id += 1

    def list_expenses(
        self,
        category: Optional[ExpenseCategory] = None,
        days: Optional[int] = None,
    ) -> list[Expense]:
        result = sorted(self._expenses, key=lambda e: e.date, reverse=True)
        if category:
            result = [e for e in result if e.category == category]
        if days:
            cutoff = date.today() - timedelta(days=days)
            result = [e for e in result if e.date >= cutoff]
        return result

    def add_expense(self, data: ExpenseCreate) -> Expense:
        expense = Expense(
            id=self._next_id,
            amount=data.amount,
            category=data.category,
            description=data.description,
            date=data.date or date.today(),
        )
        self._next_id += 1
        self._expenses.append(expense)
        return expense

    def delete_expense(self, expense_id: int) -> bool:
        for i, e in enumerate(self._expenses):
            if e.id == expense_id:
                del self._expenses[i]
                return True
        return False

    def get_summary(self, days: int = 30) -> ExpenseSummary:
        expenses = self.list_expenses(days=days)
        total = sum(e.amount for e in expenses)
        by_category: dict[str, float] = {}
        for e in expenses:
            key = e.category.value
            by_category[key] = by_category.get(key, 0) + e.amount

        months_span = max(days / 30.0, 1.0)
        return ExpenseSummary(
            total_spent=round(total, 2),
            monthly_average=round(total / months_span, 2),
            by_category={k: round(v, 2) for k, v in by_category.items()},
            expense_count=len(expenses),
        )
