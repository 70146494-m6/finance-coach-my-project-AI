# AI-Powered Personal Finance Coach

Full-stack demo: React + Tailwind dashboard, FastAPI backend with expense tracking, spending forecasts, and an AI finance coach chat.

## Features

- **Expense tracking** — View, add, and delete expenses (in-memory with sample data)
- **Dashboard** — Stats, category pie chart, recent transactions
- **Predictions** — Simple trend-based monthly spending forecast
- **AI chat** — Rule-based coach by default; optional OpenAI via `OPENAI_API_KEY`

## Prerequisites

- **Python 3.10+**
- **Node.js 18+** and npm

## Preview without Node/npm (Cursor browser)

Open the standalone preview (React + Tailwind via CDN, mock data):

1. In Cursor, press **Cmd+Shift+P** (Mac) or **Ctrl+Shift+P** (Windows)
2. Run **Simple Browser: Show**
3. Enter this URL:

```
file:///Users/momna/Documents/finance-coach/preview/index.html
```

Or open `preview/index.html` in the editor, right-click, and choose **Open with Live Preview** (if the Live Preview extension is installed).

The preview includes the full dashboard, charts, expense form, and AI chat (client-side mock coach).

## Quick start (full stack)

### 1. Backend (terminal 1)

```bash
cd finance-coach/backend
python3 -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

API docs: http://127.0.0.1:8000/docs

### 2. Frontend (terminal 2)

```bash
cd finance-coach/frontend
npm install
npm run dev
```

Open http://localhost:5173

## Optional: OpenAI-powered chat

```bash
export OPENAI_API_KEY="sk-your-key"
export OPENAI_MODEL="gpt-4o-mini"   # optional
```

Restart the backend after setting the variable.

## Project structure

```
finance-coach/
├── backend/
│   ├── main.py              # FastAPI routes
│   ├── models.py            # Pydantic schemas
│   └── services/
│       ├── expense_service.py
│       ├── prediction_service.py
│       └── ai_chat_service.py
├── frontend/
│   └── src/
│       ├── App.jsx
│       ├── api.js
│       └── components/
└── README.md
```

## API endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/expenses` | List expenses |
| POST | `/api/expenses` | Add expense |
| DELETE | `/api/expenses/{id}` | Delete expense |
| GET | `/api/summary` | Spending summary |
| GET | `/api/predictions` | Future spending forecast |
| POST | `/api/chat` | AI coach message |

## Production build

```bash
cd frontend && npm run build
# Serve dist/ with any static host; proxy /api to the FastAPI server
```
